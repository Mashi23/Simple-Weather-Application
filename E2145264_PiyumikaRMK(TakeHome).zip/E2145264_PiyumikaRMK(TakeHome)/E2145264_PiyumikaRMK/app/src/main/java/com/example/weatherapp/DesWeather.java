package com.example.weatherapp;


public class DesWeather {

    private float max_temp;
    private float min_temp;
    private float temp;
    private int humidity;
    private int pressure;
    private float windSpeed;


    public void setWindSpeed(float windSpeed) {
        this.windSpeed = windSpeed;
    }

    public String getWeatherDescription()
    {
        String weatherDescription = "";
        weatherDescription += "Current Temperature: " + temp + " \u00B0C" + "\n"+"\n" ;

        weatherDescription += "Humidity : " + humidity + "%" + "\n"+"\n";

        weatherDescription += "Max Temperature: " + max_temp + " \u00B0C" + "\n" ;
        weatherDescription += "Min Temperature: " + min_temp + " \u00B0C" + "\n";
        weatherDescription += "Atmospheric Pressure : " + pressure  + "\n";
        weatherDescription += "Wind Speed: " + windSpeed +  " m/s" + "\n";
        return weatherDescription;
    }




    public float getTemp_max() {
        return max_temp;
    }

    public void setTemp_max(float temp_max) {
        this.max_temp = temp_max;
    }


    public float getTemp_min() {
        return min_temp;
    }
    public void setTemp_min(float temp_min) {
        this.min_temp = temp_min;
    }

    public float getTemp() {
        return temp;
    }

    public void setTemp(float temp) {
        this.temp = temp;
    }


    public int getHumidity() {
        return humidity;
    }

    public void setHumidity(int humidity) {
        this.humidity = humidity;
    }

    public int getPressure() {
        return pressure;
    }

    public void setPressure(int pressure) {
        this.pressure = pressure;
    }

    public float getWindSpeed() {
        return windSpeed;
    }




}
