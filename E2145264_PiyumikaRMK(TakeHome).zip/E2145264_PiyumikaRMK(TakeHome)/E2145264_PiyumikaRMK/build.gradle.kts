
plugins {
    id("com.android.application") version "8.1.2" apply false
}